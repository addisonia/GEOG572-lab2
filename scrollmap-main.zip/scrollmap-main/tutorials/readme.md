# Mapbox Studio

### Getting Started

### Components vs. Layers

### Styling Layers

### Zoom-Controlled Styling

### Implementing Your Design

# Learning HTML/CSS Using Scrollmap

# Setting up your Workspace

### Text Editors

### Downloading Visual Studio Code

### Setting Up a Directory

# Writing HTML

### Tags

### HTML Boilerplate

### Attributes

### Common Tags and How to Write Them

# Styling with CSS

### Connecting CSS to HTML

### Styling Tags

### Classes and IDs

# Scrollmap

### The Content Container

### Rows

### Adding an element to the Story

### Left/Right Alignment

### Adding a Sidecar

### Adding an Iframe